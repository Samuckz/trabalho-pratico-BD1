package com.cefetmg.reserva_facil_laboratorios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservaFacilLaboratoriosApplicationTests {

	@Test
	void contextLoads() {
	}

}
