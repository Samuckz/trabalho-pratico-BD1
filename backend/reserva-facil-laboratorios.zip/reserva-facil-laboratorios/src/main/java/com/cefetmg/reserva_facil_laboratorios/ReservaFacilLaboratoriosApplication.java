package com.cefetmg.reserva_facil_laboratorios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservaFacilLaboratoriosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservaFacilLaboratoriosApplication.class, args);
	}

}
